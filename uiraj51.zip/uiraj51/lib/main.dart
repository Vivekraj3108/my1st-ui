import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'My 1stApp',
      home: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Text("Devclay"),
          leading: IconButton(
            onPressed: () {},
            icon: Icon(Icons.dashboard),
          ), //iconButton
          actions: [
            IconButton(
              onPressed: () {},
              icon: Icon(Icons.search),
            ) //iconButton
          ], //action
          backgroundColor: Colors.grey,
        ), //appbar

        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              //text new change the
              Container(
                margin: EdgeInsets.only(left: 30),
                height: 150.0,
                width: 350,
                //color: Colors.pinkAccent[100],
                decoration: BoxDecoration(
                  color: Colors.red[100],
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(60),
                    topRight: Radius.circular(60),
                  ),
                ),
                padding: const EdgeInsets.all(20.0),
                child: Container(
                  child: Text(
                    'We create human-centric products',
                    style: TextStyle(
                        fontSize: 23.0,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),

              ////image for new change
              Container(
                margin: EdgeInsets.only(left: 30),
                height: 400.0,
                width: 350,
                // color: Colors.pinkAccent[100],
                decoration: BoxDecoration(
                  color: Colors.red[100],
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(60),
                    bottomRight: Radius.circular(60),
                  ),
                ),
                child: Column(
                  children: [
                    ClipRRect(
                      //borderRadius: BorderRadius.circular(800),
                      child: Image.asset(
                        'images/fl.png',
                        fit: BoxFit.cover,
                        height: 200,
                        width: 200,
                      ),
                    ),
                  ],
                ),
              ),

              Container(
                margin: EdgeInsets.only(top: 5, left: 50),
                height: 50,
                width: 350,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Center(
                  child: Text(
                    "We create digital products, brands,and exprience that help our clints to grow,solve problem,and breakthrough hardship",
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      //fontWeight: FontWeight.bold,
                    ), //style
                  ), //text
                ), //center
              ), //container

              //flatButton
              Container(
                height: 100.0,
                width: 350,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.white70,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    RaisedButton(
                      onPressed: () {},
                      color: Colors.deepPurpleAccent,
                      shape: RoundedRectangleBorder(
                        borderRadius: new BorderRadius.circular(30.0),
                      ),
                      child: Row(
                        children: <Widget>[
                          IconButton(
                            icon: Icon(Icons.chat),
                            color: Color(0xFF232b2b),
                            iconSize: 25.0,
                            onPressed: () {},
                          ),
                          // iconSize: 25.0,
                          // onPressed: () {},
                          // ),
                          Text(
                            'Get in tuch',
                            style: TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ], //children
          ), //column
        ), //bodysinglechildview
      ), //scaffold
    ); //materialapp
  }
}

text() {}
