package com.example.uiraj5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
